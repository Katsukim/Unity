﻿public enum ManagerStatus {
	Shutdown,
	Initializing,
	Started
}